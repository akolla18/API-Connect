Images for the tutorial
